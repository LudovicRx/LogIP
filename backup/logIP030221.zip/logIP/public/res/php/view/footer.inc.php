<footer class="mt-auto text-white-50">
    <p>&copy; Ludovic Roux</p>
</footer>