<?php
define("INPUT_SUBMIT", "submit");// Nom de l'input submit
define("INPUT_FILE", "logFile");