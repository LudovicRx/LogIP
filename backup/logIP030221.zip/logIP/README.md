# Log IP
Le principe est de pouvoir uploader un fichier de log, puis ce dernier est parsé.
Après cela, on affiche sur une map l'emplacement des utilisateurs qui ont fait les erreurs. 
On utilisera le fichier qui est généralement access.log

# API utilisées
* ipinfo.io (pour transformer l'adresse ip en coordonnées GPS)
* bootsrap (pour le css)
* leaflet (pour la cartographie) 