<?php
require_once(__DIR__ . DIRECTORY_SEPARATOR . "control" . DIRECTORY_SEPARATOR . "functions.inc.php");
require_once(__DIR__ . DIRECTORY_SEPARATOR . "view" . DIRECTORY_SEPARATOR . "functions.inc.php");
require_once(__DIR__ . DIRECTORY_SEPARATOR . "view" . DIRECTORY_SEPARATOR . "constInput.inc.php");
