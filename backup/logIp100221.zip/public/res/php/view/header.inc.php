<header class="mb-auto">
    <div>
        <h3 class="float-md-start mb-0">Log IP</h3>
        <nav class="nav nav-masthead justify-content-center float-md-end">
            <a class="nav-link <?php echo writeActive("index.php"); ?>" aria-current="page" href="index.php">Home</a>
            <a class="nav-link <?php echo writeActive("map.php"); ?>" aria-current="page" href="map.php">Map</a>
            <a class="nav-link" href="#">About</a>
        </nav>
    </div>
</header>